import os
import time
import requests
from  sense_hat import  SenseHat
 
sense = SenseHat()

READ_API_KEY = os.getenv("THINGSPEAK_READ_API_KEY", "YOUR_READ_API_KEY")
POLL_INTERVAL_SECONDS = 10

TALKBACK_EXECUTE_URL = f"https://api.thingspeak.com/talkbacks/47206/commands/execute"


def fetch_next_command():
	response = requests.get(
		TALKBACK_EXECUTE_URL,
		params={"api_key": READ_API_KEY})
	return response.text.strip()


def handle_command(command_text):
	command = command_text.upper()
    
	if command == "ON":
		print("Command: ON")
		sense.show_message("Motion Detected!", text_colour=[255, 0, 0])  # Display message in red
		return

	if command == "OFF":
		print("Command: OFF")
		return

	print(f"Command: {command_text}")



if __name__ == "__main__":
	print("Polling ThingSpeak TalkBack queue...")
	print("Press Ctrl+C to stop.")

	while True:
		try:
			command_text = fetch_next_command()
			if command_text and command_text != "0":
				handle_command(command_text)
			else:
				print("No command available.")
		except requests.RequestException as error:
			print(f"TalkBack request failed: {error}")

		time.sleep(POLL_INTERVAL_SECONDS)
