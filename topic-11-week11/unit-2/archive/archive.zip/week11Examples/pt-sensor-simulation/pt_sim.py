from sense_hat import SenseHat
from sensor_listener import SensorListener

sense = SenseHat()

def data_detector(data):
    # data is a JSON string; e.g. {"device":"pir-01","value":1}
    print(f"Motion event received: {data}")
    if data=="true":
        print("Button press detected! Displaying message on Sense HAT.")
        sense.show_message("Motion Detected!", text_colour=[255, 0, 0])  # Display message in red

if __name__ == "__main__":
    print("Listening for Movement Events...")
    listener = SensorListener(port=5000)
    listener.callback = data_detector
    listener.start()
    while True:
        pass  # Keep the main thread alive
