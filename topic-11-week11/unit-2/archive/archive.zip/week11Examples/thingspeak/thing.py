#!/usr/bin/env python3
import requests


THINGSPEAK_UPDATE_URL = "https://api.thingspeak.com/update"
WRITE_API_KEY = "YOUR_WRITE_API_KEY"

def send_to_thingspeak(field1, field2=None):
	payload = {"api_key": WRITE_API_KEY, "field1": field1}
	if field2 is not None:
		payload["field2"] = field2

	response = requests.get(THINGSPEAK_UPDATE_URL, params=payload)
	return response.text


if __name__ == "__main__":
	temperature = 24.7
	humidity = 58.1

	entry_id = send_to_thingspeak(temperature, humidity)
	if entry_id == "0":
		print("ThingSpeak rejected the update. Check your write API key or the rate limit.")

