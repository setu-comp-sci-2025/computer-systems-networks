#!/usr/bin/env python3
import paho.mqtt.client as mqtt


MQTT_BROKER = "mqtt3.thingspeak.com"
MQTT_PORT = 1883
CHANNEL_ID = "YOUR_CHANNEL_ID"
WRITE_API_KEY = "YOUR_WRITE_API_KEY"
MQTT_TOPIC = f"channels/{CHANNEL_ID}/publish"


def publish_to_thingspeak(temperature, humidity):
	client = mqtt.Client(client_id="YOUR_CLIENT_ID")
	client.username_pw_set("YOUR_USERNAME", "YOUR_PASSWORD")
	client.connect(MQTT_BROKER, MQTT_PORT, 60)
	client.loop_start()

	payload = f"field1={temperature}&field2={humidity}"
	result = client.publish(MQTT_TOPIC, payload)
	result.wait_for_publish()

	client.loop_stop()
	client.disconnect()

	return result.rc


if __name__ == "__main__":
	temperature = 23
	humidity = 40

	result_code = publish_to_thingspeak(temperature, humidity)
	if result_code != mqtt.MQTT_ERR_SUCCESS:
		raise RuntimeError(f"ThingSpeak MQTT publish failed with code {result_code}")

	print("Uploaded successfully to ThingSpeak via MQTT.")
